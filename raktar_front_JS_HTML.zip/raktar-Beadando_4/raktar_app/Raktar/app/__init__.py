from apiflask import APIFlask
from config import Config
from app.extensions import db
from app.models import *
from flask_cors import CORS
from flask_migrate import Migrate

def create_app(config_class=Config):
    app = APIFlask(__name__, json_errors=True,
                   title="Raktár API",
                   docs_path="/swagger")
    app.config.from_object(config_class)

    # Inicializálás
    db.init_app(app)
    migrate = Migrate(app, db, render_as_batch=True)

    # CORS engedélyezés
    CORS(app)

    # Blueprint regisztrálás
    from app.blueprints import bp as bp_default
    app.register_blueprint(bp_default, url_prefix='/api')

    return app