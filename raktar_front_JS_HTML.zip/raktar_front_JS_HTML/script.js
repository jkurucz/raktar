const API_URL = 'http://localhost:8000/api/products';

document.addEventListener('DOMContentLoaded', () => {
    fetchProducts();
    document.getElementById('product-form').addEventListener('submit', handleFormSubmit);
    document.getElementById('searchInput').addEventListener('input', (e) => {
        fetchProducts(e.target.value);
    });
});

function fetchProducts(search = '') {
    const url = search ? `${API_URL}?name=${encodeURIComponent(search)}` : API_URL;
    fetch(url)
        .then(response => {
            if (!response.ok) throw new Error('Hiba a lekérdezés során');
            return response.json();
        })
        .then(products => {
            const tableBody = document.querySelector('#product-table tbody');
            tableBody.innerHTML = '';
            products.forEach(product => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${product.id}</td>
                    <td>${product.name}</td>
                    <td>${product.price}</td>
                    <td>${product.warehouse_id}</td>
                    <td>
                        <button class="action-button edit-btn" onclick="editProduct(${product.id})">Szerkesztés</button>
                        <button class="action-button delete-btn" onclick="deleteProduct(${product.id})">Törlés</button>
                    </td>
                `;
                tableBody.appendChild(row);
            });
        })
        .catch(error => alert(`Hiba: ${error.message}`));
}

// Validációs funkció
function validateForm() {
    const name = document.getElementById('name').value;
    const price = document.getElementById('price').value;
    const warehouse_id = document.getElementById('warehouse_id').value;

    // Hibák tárolása
    let errors = [];

    if (!name.trim()) errors.push('A termék neve nem lehet üres!');
    if (!price || isNaN(price) || price <= 0) errors.push('Érvényes ár szükséges!');
    if (!warehouse_id || isNaN(warehouse_id) || warehouse_id <= 0) errors.push('Érvényes raktár ID szükséges!');

    // Hibák kiírása
    const errorContainer = document.getElementById('error-messages');
    errorContainer.innerHTML = '';
    if (errors.length > 0) {
        errors.forEach(error => {
            const errorMsg = document.createElement('p');
            errorMsg.textContent = error;
            errorContainer.appendChild(errorMsg);
        });
        return false; // Ha van hiba, ne küldjük el az űrlapot
    }
    
    return true; // Ha nincs hiba, folytathatjuk a műveletet
}

// A form submit eseményhez a validációt hívjuk meg
function handleFormSubmit(event) {
    event.preventDefault();
    if (validateForm()) {
        const id = document.getElementById('product-id').value;
        if (id) updateProduct(id);
        else addProduct();
    }
}

function addProduct() {
    const name = document.getElementById('name').value;
    const price = parseFloat(document.getElementById('price').value);
    const warehouse_id = parseInt(document.getElementById('warehouse_id').value);

    fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, price, warehouse_id })
    })
    .then(response => {
        if (!response.ok) throw new Error('Hiba történt a termék hozzáadása közben');
        return response.json();
    })
    .then(() => {
        closeModal();
        fetchProducts();
    })
    .catch(error => alert(error.message));
}

function deleteProduct(id) {
    fetch(`${API_URL}/${id}`, { method: 'DELETE' })
        .then(response => {
            if (!response.ok) throw new Error('Törlés sikertelen!');
            return response.json();
        })
        .then(() => fetchProducts())
        .catch(error => alert(`Hiba történt: ${error.message}`));
}

function editProduct(id) {
    fetch(`${API_URL}/${id}`)
        .then(response => response.json())
        .then(product => {
            document.getElementById('product-id').value = product.id;
            document.getElementById('name').value = product.name;
            document.getElementById('price').value = product.price;
            document.getElementById('warehouse_id').value = product.warehouse_id;
            document.getElementById('submit-button').textContent = 'Mentés';
            openModal();
        })
        .catch(error => alert(`Nem sikerült betölteni a terméket: ${error.message}`));
}

function updateProduct(id) {
    const name = document.getElementById('name').value;
    const price = parseFloat(document.getElementById('price').value);
    const warehouse_id = parseInt(document.getElementById('warehouse_id').value);

    fetch(`${API_URL}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, price, warehouse_id })
    })
    .then(response => {
        if (!response.ok) throw new Error('Frissítés sikertelen!');
        return response.json();
    })
    .then(() => {
        closeModal();
        fetchProducts();
    })
    .catch(error => alert(`Hiba: ${error.message}`));
}

function resetForm() {
    document.getElementById('product-form').reset();
    document.getElementById('product-id').value = '';
    document.getElementById('submit-button').textContent = 'Hozzáadás';
    document.getElementById('error-messages').innerHTML = '';
}

function openModal() {
    document.getElementById('product-modal').style.display = 'block';
}

function closeModal() {
    document.getElementById('product-modal').style.display = 'none';
    resetForm();
}

window.onclick = function(event) {
    const modal = document.getElementById('product-modal');
    if (event.target === modal) closeModal();
}


function searchProducts() {
    const searchInput = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.querySelectorAll('#product-table tbody tr');
    rows.forEach(row => {
        const nameCell = row.cells[1].textContent.toLowerCase();
        if (nameCell.includes(searchInput)) {
            row.style.display = '';  // Ha egyezik, megjelenítjük
        } else {
            row.style.display = 'none';  // Ha nem egyezik, elrejtjük
        }
    });
}